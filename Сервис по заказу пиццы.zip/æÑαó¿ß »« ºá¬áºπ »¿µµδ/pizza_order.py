import time
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from tkinter import Entry

root = tk.Tk()
root.title("Приложение для заказа пиццы")
root.geometry("915x700")
lbl = tk.Label(root, text="Добро пожаловать\n Выберите пиццу", font="ROBOTO, 15").grid(row=1, column=6)
root.configure(bg='#B1F6B8')


def clicked_1():
    messagebox.showinfo(title="Цена 100",
                        message="Пеперо́ни (англ. pepperoni, итал. peperoni) — острая разновидность салями "
                                "итало-американского происхождения,"
                                "приготовленная из вяленого мяса и приправленная паприкой или разновидностями перца "
                                "чили")


def clicked_2():
    messagebox.showinfo(title="Цена 90",
                        message="Описание Пицца BBQ 33 см. - это сочетание пикантной итальянской колбасы Салями, "
                                "нежного сыра Моцарелла, сочной ветчины, грибов и специального пряного соуса BBQ на "
                                "хрустящем тесте")


def clicked_3():
    messagebox.showinfo(title="Цена 120", message="Дары Моря- пицца с различными морепродуктами")


def clicked_4():
    messagebox.showinfo(title='Цена 300',
                        message='Это разновидность пиццы, приготовленной с помидорами и сыром моцарелла.')


def clicked_5():
    messagebox.showinfo(title='Цена 80',
                        message='Пицца прямоугольной формы, в состав входит: \n\n  Томатная пассата, Моцарелла, '
                                'Маслины, Бекон, Сухие травы')


def clicked_6():
    messagebox.showinfo(title='Цена 400',
                        message='Пицца Нью-Йорк или Нью-Йоркская пицца / пицца по-ньюйоркски (New York-style pizza) – '
                                'традиционное блюдо кухни США, наиболее популярное на северо-востоке Соединенных '
                                'Штатов. Пицца Нью-Йорк представляет собой пиццу на тонком тесте с начинкой из '
                                'пряного томатного соуса и сыра моцарелла в базовом варианте.')


def clicked_7():
    messagebox.showinfo(title='Цена 320',
                        message='Пицца по-чикагски (англ. Chicago-style pizza), также deep dish pizza (пицца в глубоком блюде) — вариант пиццы с высокими бортиками, придуманный в Чикаго. Глубокая сковорода, в которой она выпекается, придает пицце характерно высокий край, который обеспечивает достаточно места для большого количества сыра и густого томатного соуса.')


def clicked_8():
    messagebox.showinfo(title='Цена 220',
                        message='Греческая пицца - это разновидность пиццы с корочкой и приготовлением, при которой пиццу смазывают и готовят на металлической сковороде, а не растягивают по заказу и запекают на дне печи для пиццы.')


class Pepperoni():
    canvas = tk.Canvas(root, height=100, width=100)
    image = Image.open("pizza_image/pepperoni.png")
    new_width = 100
    new_height = 100
    image = image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    image = canvas.create_image(0, 0, anchor='nw', image=photo)
    canvas.grid(row=2, column=4)
    tk.Label(root, text='Пеперо́ни, \nномер пиццы - 1', font="ROBOTO, 15").grid(row=3, column=4)
    btn_1 = tk.Button(root, text='Информация', command=clicked_1).grid(row=4, column=4)


class Barbekyu():
    canvas = tk.Canvas(root, height=100, width=100)
    image = Image.open("pizza_image/bbq.jpg")
    new_width = 100
    new_height = 100
    image = image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    image = canvas.create_image(0, 0, anchor='nw', image=photo)
    canvas.grid(row=2, column=5)
    lbl = tk.Label(root, text='BBQ, \nномер пиццы - 2', font="ROBOTO, 15").grid(row=3, column=5)
    btn_2 = tk.Button(root, text='Информация', command=clicked_2).grid(row=4, column=5)


class Dary():
    canvas = tk.Canvas(root, height=100, width=100)
    image = Image.open("pizza_image/sea_pizza.jpg")
    new_width = 100
    new_height = 100
    image = image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    image = canvas.create_image(0, 0, anchor='nw', image=photo)
    canvas.grid(row=2, column=6)
    lbl = tk.Label(root, text='Дары моря, \n номер пиццы - 3', font="ROBOTO, 15").grid(row=3, column=6)
    btn_3 = tk.Button(root, text='Информация', command=clicked_3).grid(row=4, column=6)


class Neapolitan():
    canvas = tk.Canvas(root, height=100, width=100)
    image = Image.open("pizza_image/neapolitan.jpg")
    new_width = 100
    new_height = 100
    image = image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    image = canvas.create_image(0, 0, anchor='nw', image=photo)
    canvas.grid(row=2, column=7)
    lbl = tk.Label(root, text='Неаполитанская, \n номер пиццы - 4', font="ROBOTO, 15").grid(row=3, column=7)
    btn_4 = tk.Button(root, text='Информация', command=clicked_4).grid(row=4, column=7)


class Rim():
    canvas = tk.Canvas(root, height=100, width=100)
    image = Image.open("pizza_image/rim_pizza.jpg")
    new_width = 100
    new_height = 100
    image = image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    image = canvas.create_image(0, 0, anchor='nw', image=photo)
    canvas.grid(row=2, column=8)
    lbl = tk.Label(root, text='Римская, \n номер пиццы - 5', font="ROBOTO, 15").grid(row=3, column=8)
    btn_4 = tk.Button(root, text='Информация', command=clicked_5).grid(row=4, column=8)


class New_York():
    canvas = tk.Canvas(root, height=100, width=100)
    image = Image.open("pizza_image/new_york.jpg")
    new_width = 100
    new_height = 100
    image = image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    image = canvas.create_image(0, 0, anchor='nw', image=photo)
    canvas.grid(row=5, column=5)
    lbl = tk.Label(root, text='Нью-йорк, \n номер пиццы - 6', font="ROBOTO, 15").grid(row=6, column=5)
    btn_4 = tk.Button(root, text='Информация', command=clicked_6).grid(row=7, column=5)


class Chikago():
    canvas = tk.Canvas(root, height=100, width=100)
    image = Image.open("pizza_image/chikago.jpg")
    new_width = 100
    new_height = 100
    image = image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    image = canvas.create_image(0, 0, anchor='nw', image=photo)
    canvas.grid(row=5, column=6)
    lbl = tk.Label(root, text='Чикаго, \n номер пиццы - 7', font="ROBOTO, 15").grid(row=6, column=6)
    btn_4 = tk.Button(root, text='Информация', command=clicked_7).grid(row=7, column=6)


class Grek():
    canvas = tk.Canvas(root, height=100, width=100)
    image = Image.open("pizza_image/grek_pizza.jpg")
    new_width = 100
    new_height = 100
    image = image.resize((new_width, new_height))
    photo = ImageTk.PhotoImage(image)
    image = canvas.create_image(0, 0, anchor='nw', image=photo)
    canvas.grid(row=5, column=7)
    lbl = tk.Label(root, text='Греческая, \n номер пиццы - 8', font="ROBOTO, 15").grid(row=6, column=7)
    btn_4 = tk.Button(root, text='Информация', command=clicked_8).grid(row=7, column=7)


def pok_peperoni():
    try:
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - 100
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    except:
        messagebox.showerror(title='Ошибка выполнения заказа', message='При выполнениии операции произошла ошибка, пожалуйста повторите ее позже')

def pok_bbq():
    try:
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - 90
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    except:
        messagebox.showerror(title='Ошибка выполнения заказа', message='При выполнениии операции произошла ошибка, пожалуйста повторите ее позже')

def pok_sea():
    try:
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - 120
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    except:
        messagebox.showerror(title='Ошибка выполнения заказа', message='При выполнениии операции произошла ошибка, пожалуйста повторите ее позже')

def pok_neapolitan():
    try:
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - 300
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    except:
        messagebox.showerror(title='Ошибка выполнения заказа', message='При выполнениии операции произошла ошибка, пожалуйста повторите ее позже')

def pok_rim():
    try:
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - 80
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    except:
        messagebox.showerror(title='Ошибка выполнения заказа', message='При выполнениии операции произошла ошибка, пожалуйста повторите ее позже')

def pok_new_york():
    try:
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - 400
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    except:
        messagebox.showerror(title='Ошибка выполнения заказа', message='При выполнениии операции произошла ошибка, пожалуйста повторите ее позже')

def pok_chikago():
    try:
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - 320
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    except:
        messagebox.showerror(title='Ошибка выполнения заказа', message='При выполнениии операции произошла ошибка, пожалуйста повторите ее позже')

def pok_grek():
    try:
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - 220
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    except:
        messagebox.showerror(title='Ошибка выполнения заказа', message='При выполнениии операции произошла ошибка, пожалуйста повторите ее позже')



def pepperonni():
    if int(balance_text.get('1.0', tk.END).strip()) >= int(100):
        balance = balance_text.get('1.0', tk.END).split()
        sale = 100
        a = tk.Toplevel()
        a.title("Подтверждение заказа на Пеперо́ни")
        a.geometry('200x300')
        a['bg'] = '#FFEC86'
        tk.Label(a, text="Цена", font="ROBOTO 25").pack()
        tk.Label(a, text=f'{sale}', font="ROBOTO, 30").pack()
        but = tk.Button(a, text="Покупаю", command=pok_peperoni).pack()
        but_d = tk.Button(a, text="Не покупаю", command=a.destroy).pack()
    else:
        messagebox.showerror(title='Недостаточно средств', message='Недостаточно средств на балансе, проверьте его и при необходимости пополните')

def bbq():
    if int(balance_text.get('1.0', tk.END).strip()) >= int(90):
        a = tk.Toplevel()
        a.title("Подтверждение заказа на BBQ")
        a.geometry('500x500')
        sale = 90
        a['bg'] = '#FFEC86'
        tk.Label(a, text="Цена", font="ROBOTO 25").pack()
        tk.Label(a, text=f'{sale}', font="ROBOTO, 30").pack()
        but = tk.Button(a, text="Покупаю", command=pok_bbq).pack()
        but_d = tk.Button(a, text="Не покупаю", command=a.destroy).pack()
    else:
        messagebox.showerror(title='Недостаточно средств', message='Недостаточно средств на балансе, проверьте его и при необходимости пополните')

def sea():
    if int(balance_text.get('1.0', tk.END).strip()) >= int(120):
        a = tk.Toplevel()
        a.title("Подтверждение заказа на Дары-моря")
        a.geometry('500x500')
        sale = 120
        a['bg'] = '#FFEC86'
        tk.Label(a, text="Цена", font="ROBOTO 25").pack()
        tk.Label(a, text=f'{sale}', font="ROBOTO, 30").pack()
        but = tk.Button(a, text="Покупаю", command=pok_sea).pack()
        but_d = tk.Button(a, text="Не покупаю", command=a.destroy).pack()
    else:
        messagebox.showerror(title='Недостаточно средств', message='Недостаточно средств на балансе, проверьте его и при необходимости пополните')



def neapolitan():
    if int(balance_text.get('1.0', tk.END).strip()) >= int(300):
        a = tk.Toplevel()
        a.title("Подтверждение заказа на Неаполитанскую")
        a.geometry('500x500')
        sale = 300
        a['bg'] = '#FFEC86'
        tk.Label(a, text="Цена", font="ROBOTO 25").pack()
        tk.Label(a, text=f'{sale}', font="ROBOTO, 30").pack()
        but = tk.Button(a, text="Покупаю", command=pok_neapolitan).pack()
        but_d = tk.Button(a, text="Не покупаю", command=a.destroy).pack()
    else:
        messagebox.showerror(title='Недостаточно средств', message='Недостаточно средств на балансе, проверьте его и при необходимости пополните')

def rim():
    if int(balance_text.get('1.0', tk.END).strip()) >= int(80):
        a = tk.Toplevel()
        a.title("Подтверждение заказа на Римскую")
        a.geometry('500x500')
        sale = 80
        a['bg'] = '#FFEC86'
        tk.Label(a, text="Цена", font="ROBOTO 25").pack()
        tk.Label(a, text=f'{sale}', font="ROBOTO, 30").pack()
        but = tk.Button(a, text="Покупаю", command=pok_rim).pack()
        but_d = tk.Button(a, text="Не покупаю", command=a.destroy).pack()
    else:
        messagebox.showerror(title='Недостаточно средств', message='Недостаточно средств на балансе, проверьте его и при необходимости пополните')


def new_york():
    if int(balance_text.get('1.0', tk.END).strip()) >= int(400):
        a = tk.Toplevel()
        a.title("Подтверждение заказа на Нью-йорк")
        a.geometry('500x500')
        sale = 400
        a['bg'] = '#FFEC86'
        tk.Label(a, text="Цена", font="ROBOTO 25").pack()
        tk.Label(a, text=f'{sale}', font="ROBOTO, 30").pack()
        but = tk.Button(a, text="Покупаю", command=pok_new_york).pack()
        but_d = tk.Button(a, text="Не покупаю", command=a.destroy).pack()
    else:
        messagebox.showerror(title='Недостаточно средств', message='Недостаточно средств на балансе, проверьте его и при необходимости пополните')


def chikago():
    if int(balance_text.get('1.0', tk.END).strip()) >= int(320):
        a = tk.Toplevel()
        a.title("Подтверждение заказа на Чикаго")
        a.geometry('500x500')
        sale = 320
        a['bg'] = '#FFEC86'
        tk.Label(a, text="Цена", font="ROBOTO 25").pack()
        tk.Label(a, text=f'{sale}', font="ROBOTO, 30").pack()
        but = tk.Button(a, text="Покупаю", command=pok_chikago).pack()
        but_d = tk.Button(a, text="Не покупаю", command=a.destroy).pack()
    else:
        messagebox.showerror(title='Недостаточно средств', message='Недостаточно средств на балансе, проверьте его и при необходимости пополните')


def grek():
    if int(balance_text.get('1.0', tk.END).strip()) >= int(220):
        a = tk.Toplevel()
        a.title("Подтверждение заказа на Греческую")
        a.geometry('500x500')
        sale = 220
        a['bg'] = '#FFEC86'
        tk.Label(a, text="Цена", font="ROBOTO 25").pack()
        tk.Label(a, text=f'{sale}', font="ROBOTO, 30").pack()
        but = tk.Button(a, text="Покупаю", command=pok_grek).pack()
        but_d = tk.Button(a, text="Не покупаю", command=a.destroy).pack()
    else:
        messagebox.showerror(title='Недостаточно средств', message='Недостаточно средств на балансе, проверьте его и при необходимости пополните')


def pepperonni_kor():
    title = empty_entry.get(tk.END)
    new_title = f'Пеперони{title}\n'
    empty_entry.configure(state=tk.NORMAL)
    empty_entry.insert(tk.END, new_title)
    empty_entry.configure(state=tk.DISABLED)
    current_price = empty_entry_sale.get("1.0", tk.END).strip()
    current_price = int(current_price) if current_price else 0
    new_price = current_price + 100
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.delete("1.0", tk.END)
    empty_entry_sale.configure(state=tk.DISABLED)
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.insert(tk.END, str(new_price))
    empty_entry_sale.configure(state=tk.DISABLED)


def bbq_kor():
    title = empty_entry.get(tk.END)
    new_title = f'BBQ{title}\n'
    empty_entry.configure(state=tk.NORMAL)
    empty_entry.insert(tk.END, new_title)
    empty_entry.configure(state=tk.DISABLED)
    current_price = empty_entry_sale.get("1.0", tk.END).strip()
    current_price = int(current_price) if current_price else 0
    new_price = current_price + 90
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.delete("1.0", tk.END)
    empty_entry_sale.configure(state=tk.DISABLED)
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.insert(tk.END, str(new_price))
    empty_entry_sale.configure(state=tk.DISABLED)


def sea_kor():
    title = empty_entry.get(tk.END)
    new_title = f'Дары-моря{title}\n'
    empty_entry.configure(state=tk.NORMAL)
    empty_entry.insert(tk.END, new_title)
    empty_entry.configure(state=tk.DISABLED)
    current_price = empty_entry_sale.get("1.0", tk.END).strip()
    current_price = int(current_price) if current_price else 0
    new_price = current_price + 120
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.delete("1.0", tk.END)
    empty_entry_sale.configure(state=tk.DISABLED)
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.insert(tk.END, str(new_price))
    empty_entry_sale.configure(state=tk.DISABLED)


def neapolitan_kor():
    title = empty_entry.get(tk.END)
    new_title = f'Неополитанская{title}\n'
    empty_entry.configure(state=tk.NORMAL)
    empty_entry.insert(tk.END, new_title)
    empty_entry.configure(state=tk.DISABLED)
    current_price = empty_entry_sale.get("1.0", tk.END).strip()
    current_price = int(current_price) if current_price else 0
    new_price = current_price + 300
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.delete("1.0", tk.END)
    empty_entry_sale.configure(state=tk.DISABLED)
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.insert(tk.END, str(new_price))
    empty_entry_sale.configure(state=tk.DISABLED)


def rim_kor():
    title = empty_entry.get(tk.END)
    new_title = f'Римсткая{title}\n'
    empty_entry.configure(state=tk.NORMAL)
    empty_entry.insert(tk.END, new_title)
    empty_entry.configure(state=tk.DISABLED)
    current_price = empty_entry_sale.get("1.0", tk.END).strip()
    current_price = int(current_price) if current_price else 0
    new_price = current_price + 80
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.delete("1.0", tk.END)
    empty_entry_sale.configure(state=tk.DISABLED)
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.insert(tk.END, str(new_price))
    empty_entry_sale.configure(state=tk.DISABLED)


def new_york_kor():
    title = empty_entry.get(tk.END)
    new_title = f'Нью-йорк{title}\n'
    empty_entry.configure(state=tk.NORMAL)
    empty_entry.insert(tk.END, new_title)
    empty_entry.configure(state=tk.DISABLED)
    current_price = empty_entry_sale.get("1.0", tk.END).strip()
    current_price = int(current_price) if current_price else 0
    new_price = current_price + 400
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.delete("1.0", tk.END)
    empty_entry_sale.configure(state=tk.DISABLED)
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.insert(tk.END, str(new_price))
    empty_entry_sale.configure(state=tk.DISABLED)


def chikago_kor():
    title = empty_entry.get(tk.END)
    new_title = f'Чикаго{title}\n'
    empty_entry.configure(state=tk.NORMAL)
    empty_entry.insert(tk.END, new_title)
    empty_entry.configure(state=tk.DISABLED)
    current_price = empty_entry_sale.get("1.0", tk.END).strip()
    current_price = int(current_price) if current_price else 0
    new_price = current_price + 320
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.delete("1.0", tk.END)
    empty_entry_sale.configure(state=tk.DISABLED)
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.insert(tk.END, str(new_price))
    empty_entry_sale.configure(state=tk.DISABLED)



def grek_kor():
    title = empty_entry.get(tk.END)
    new_title = f'Греческая{title}\n'
    empty_entry.configure(state=tk.NORMAL)
    empty_entry.insert(tk.END, new_title)
    empty_entry.configure(state=tk.DISABLED)
    current_price = empty_entry_sale.get("1.0", tk.END).strip()
    current_price = int(current_price) if current_price else 0
    new_price = current_price + 220
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.delete("1.0", tk.END)
    empty_entry_sale.configure(state=tk.DISABLED)
    empty_entry_sale.configure(state=tk.NORMAL)
    empty_entry_sale.insert(tk.END, str(new_price))
    empty_entry_sale.configure(state=tk.DISABLED)



def error():
    a = tk.Toplevel()
    a.title('Такой пиццы не существует')
    a.geometry('350x50')
    a['bg'] = '#FFEC86'
    tk.Label(a, text="Такой пиццы не существует, \nпожалуйста вернитесь назад и выберите пиццу из меню",
             font="ROBOTO 10").grid(column=1, row=5)


def none():
    a = tk.Toplevel()
    a.title('Вы не выбрали пиццу')
    a.geometry('500x500')
    a['bg'] = '#FFEC86'
    tk.Label(a, text="Вы не выбрали пиццу,\n пожалуйста вернитесь назад и выберите пиццу", font="ROBOTO 10").grid(
        column=1, row=5)


def retrieve_input():
    entered_text = entry.get()
    return entered_text


def zakaz():
    try:
        entry_text = int(retrieve_input())
        if entry_text == 1:
            return pepperonni()
        elif entry_text == 2:
            return bbq()
        elif entry_text == 3:
            return sea()
        elif entry_text == 4:
            return neapolitan()
        elif entry_text == 5:
            return rim()
        elif entry_text == 6:
            return new_york()
        elif entry_text == 7:
            return chikago()
        elif entry_text == 8:
            return grek()
        else:
            return error()
    except:
        return none()


def korzina():
    try:
        entry_text = int(retrieve_input())
        if entry_text == 1:
            return pepperonni_kor()
        elif entry_text == 2:
            return bbq_kor()
        elif entry_text == 3:
            return sea_kor()
        elif entry_text == 4:
            return neapolitan_kor()
        elif entry_text == 5:
            return rim_kor()
        elif entry_text == 6:
            return new_york_kor()
        elif entry_text == 7:
            return chikago_kor()
        elif entry_text == 8:
            return grek_kor()
        else:
            return error()
    except:
        return none()



def korzina_get_text():
    text = empty_entry.get("1.0", tk.END)
    return text


def korzina_get_int():
    sales = empty_entry_sale.get("1.0", tk.END)
    return int(sales)


def pok_korzina():
    if int(balance_text.get('1.0', tk.END)) >= int(empty_entry_sale.get('1.0', tk.END)):
        current_price = balance_text.get("1.0", tk.END).strip()
        new_price = int(current_price) - int(empty_entry_sale.get('1.0', tk.END))
        balance_text.config(state=tk.NORMAL)
        balance_text.delete("1.0", tk.END)
        balance_text.insert(tk.END, str(new_price))
        balance_text.config(state=tk.DISABLED)
        messagebox.showinfo("Принято", f"Пожалуйста ожидайте")
        time.sleep(3)
        messagebox.showinfo("Готово", f"Пожалуйста забирайте заказ")
    else:
        messagebox.showerror("Недостаточно средств", "Пожалуйста пополните счет")


def korzina_zakaz():
    text = str(korzina_get_text())
    sales = int(korzina_get_int())
    a = tk.Toplevel()
    a.title('Ваша корзина с заказом')
    a.geometry('900x900')
    a['bg'] = '#FFEC86'
    if not text:
        tk.Label(a, text='Ваша корзина пуста', font='ROBOTO 25', height=10, width=17).pack()
    else:
        tk.Label(a, text=f'{text}Позиции корзины').pack()
        tk.Label(a, text=f'Цена корзины{sales}').pack()
        tk.Button(a, text="Покупаю", command=pok_korzina).pack()
        tk.Button(a, text="Не покупаю", command=a.destroy).pack()

tk.Label(root, text='Ваш баланс', font='ROBOTO 15').grid(row=10, column=7)
balance_text = tk.Text(root, width=10, height=1, state=tk.DISABLED)
balance_text.grid(row=9, column=7)

def clear_entry():
    entry.delete(0, tk.END)


def default_balance():
    balance_text.get('1.0', tk.END)
    balance_text.config(state=tk.NORMAL)
    balance_text.delete('1.0', tk.END)
    balance_text.insert('1.0', '0')
    balance_text.config(state=tk.DISABLED)


def add_balance():
    current_price = balance_text.get("1.0", tk.END).strip()
    new_price = int(current_price) + 100
    balance_text.configure(state=tk.NORMAL)
    balance_text.delete("1.0", tk.END)
    balance_text.configure(state=tk.DISABLED)
    balance_text.configure(state=tk.NORMAL)
    balance_text.insert(tk.END, str(new_price))
    balance_text.configure(state=tk.DISABLED)


add = tk.Button(root, text='Пополнить баланс', command=add_balance)
add.grid(row=9, column=8)

empty_entry = tk.Text(root, width=17, height=10)
empty_entry.configure(state=tk.DISABLED)
empty_entry.grid(row=8, column=4)

empty_entry_sale = tk.Text(root, width=10, height=1)
empty_entry_sale.configure(state=tk.DISABLED)
empty_entry_sale.grid(row=8, column=5)


zakaz_entry = tk.Button(root, text='Перейти к оплате', command=korzina_zakaz)
zakaz_entry.grid(row=9, column=4)


default_balance()


entry = Entry(root)
entry.grid(row=8, column=6)

button = tk.Button(root, text='Введите номер пиццы которую хотите заказать\n\n после нажмите для подтверждения', command=zakaz)
button.grid(row=9, column=6)



korzina_button = tk.Button(root, text='Добавить в корзину', command=korzina)
korzina_button.grid(row=8, column=7)

clear_button = tk.Button(root, text="Очистить поле", command=clear_entry)
clear_button.grid(row=8, column=8)

button_d = tk.Button(root, text='Выход', command=root.destroy).grid(row=10, column=6)

root.mainloop()
